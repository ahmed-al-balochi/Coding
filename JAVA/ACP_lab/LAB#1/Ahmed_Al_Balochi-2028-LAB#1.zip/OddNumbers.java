class OddNumbers{
public static void main(String[] args){
	System.out.println("Odd Numbers from 1 to 20: ");
	for(int i = 1; i<=20; i = i +2){
	System.out.println(i);
		}
	}
}
